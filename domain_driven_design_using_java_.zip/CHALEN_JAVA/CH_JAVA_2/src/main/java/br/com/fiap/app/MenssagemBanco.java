package br.com.fiap.app;

import br.com.fiap.model.Menssagem;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MenssagemBanco {
    private Connection con;

    public MenssagemBanco(Connection con) {
        this.con = con;
    }

    public MenssagemBanco() {
    }


    public boolean perguntaExiste(String pergunta) throws SQLException {
        String sql = "SELECT COUNT(*) FROM ch_Menssagens WHERE pergunta = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, pergunta);
        ResultSet rs = stmt.executeQuery();
        boolean existe = false;
        if (rs.next()) {
            existe = rs.getInt(1) > 0;
        }
        rs.close();
        stmt.close();
        return existe;
    }


    public void adicionarMenssagem(Menssagem menssagem) throws SQLException {
        if (perguntaExiste(menssagem.getPergunta())) {
            throw new SQLException("Essa pergunta já foi cadastrada!");
        }

        String sql = "INSERT INTO ch_Menssagens (pergunta, resposta) VALUES (?, ?) RETURNING id INTO ?";
        oracle.jdbc.OraclePreparedStatement stmt =
                (oracle.jdbc.OraclePreparedStatement) con.prepareStatement(sql);
        stmt.setString(1, menssagem.getPergunta());
        stmt.setString(2, menssagem.getResposta());
        stmt.registerReturnParameter(3, java.sql.Types.INTEGER);

        stmt.executeUpdate();

        ResultSet rs = stmt.getReturnResultSet();
        if (rs.next()) {
            menssagem.setId(rs.getInt(1));
        }

        rs.close();
        stmt.close();
    }




    public Menssagem buscarPorPergunta(String pergunta) throws SQLException {
        String sql = "SELECT * FROM ch_Menssagens WHERE pergunta = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, pergunta);
        ResultSet rs = stmt.executeQuery();
        Menssagem menssagem = null;
        if (rs.next()) {
            menssagem = new Menssagem(
                    rs.getInt("id"),
                    rs.getString("pergunta"),
                    rs.getString("resposta")
            );
        }
        rs.close();
        stmt.close();
        return menssagem;
    }


    public Menssagem buscarPorId(int id) throws SQLException {
        String sql = "SELECT * FROM ch_Menssagens WHERE id = ? ORDER BY id";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        Menssagem menssagem = null;
        if (rs.next()) {
            menssagem = new Menssagem(
                    rs.getInt("id"),
                    rs.getString("pergunta"),
                    rs.getString("resposta")
            );
        }
        rs.close();
        stmt.close();
        return menssagem;
    }


    public List<Menssagem> listarMenssagens() throws SQLException {
        String sql = "SELECT * FROM ch_Menssagens";
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        List<Menssagem> menssagens = new ArrayList<>();
        while (rs.next()) {
            menssagens.add(new Menssagem(
                    rs.getInt("id"),
                    rs.getString("pergunta"),
                    rs.getString("resposta")
            ));
        }
        rs.close();
        stmt.close();
        return menssagens;
    }


    public void atualizarMenssagem(Menssagem menssagem) throws SQLException {
        String sql = "UPDATE ch_Menssagens SET pergunta = ?, resposta = ? WHERE id = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, menssagem.getPergunta());
        stmt.setString(2, menssagem.getResposta());
        stmt.setInt(3, menssagem.getId());
        stmt.executeUpdate();
        stmt.close();
    }


    public void deletarMenssagem(int id) throws SQLException {
        String sql = "DELETE FROM ch_Menssagens WHERE id = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.executeUpdate();
        stmt.close();
    }


}
